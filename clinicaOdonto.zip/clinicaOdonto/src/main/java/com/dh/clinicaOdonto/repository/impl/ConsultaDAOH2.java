package com.dh.clinicaOdonto.repository.impl;

import org.springframework.stereotype.Repository;

@Repository
public class ConsultaDAOH2 {
}
