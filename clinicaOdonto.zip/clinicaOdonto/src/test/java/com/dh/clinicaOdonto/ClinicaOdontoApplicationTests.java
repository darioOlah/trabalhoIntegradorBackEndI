package com.dh.clinicaOdonto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
